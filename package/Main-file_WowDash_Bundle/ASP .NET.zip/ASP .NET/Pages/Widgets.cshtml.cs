using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages
{
    public class WidgetsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
