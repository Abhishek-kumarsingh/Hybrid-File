using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.CryptoCurrency
{
    public class MarketplaceDetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
