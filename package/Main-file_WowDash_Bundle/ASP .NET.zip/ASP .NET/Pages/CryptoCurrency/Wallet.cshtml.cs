using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.CryptoCurrency
{
    public class WalletModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
