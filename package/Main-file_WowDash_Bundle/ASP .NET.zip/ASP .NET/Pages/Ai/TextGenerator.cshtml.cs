using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Ai
{
    public class TextGeneratorModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
