using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Ai
{
    public class ImageGeneratorModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
