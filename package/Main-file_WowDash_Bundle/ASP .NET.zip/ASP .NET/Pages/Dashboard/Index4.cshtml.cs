using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Dashboard
{
    public class Index4Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
