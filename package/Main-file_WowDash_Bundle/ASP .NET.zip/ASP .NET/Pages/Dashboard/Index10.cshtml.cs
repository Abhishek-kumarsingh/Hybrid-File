using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Dashboard
{
    public class Index10Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
