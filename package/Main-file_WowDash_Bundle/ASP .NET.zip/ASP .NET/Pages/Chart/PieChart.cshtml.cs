using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Chart
{
    public class PieChartModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
