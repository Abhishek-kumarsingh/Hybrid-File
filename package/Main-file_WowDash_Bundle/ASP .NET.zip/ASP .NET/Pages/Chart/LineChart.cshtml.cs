using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Chart
{
    public class LineChartModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
