using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Chart
{
    public class ColumnChartModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
