using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Forms
{
    public class InputLayoutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
