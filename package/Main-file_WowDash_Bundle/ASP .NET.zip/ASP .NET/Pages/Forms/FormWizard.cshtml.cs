using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Forms
{
    public class FormWizardModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
