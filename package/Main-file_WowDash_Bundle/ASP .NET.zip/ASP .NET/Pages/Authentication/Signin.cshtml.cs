using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Authentication
{
    public class SigninModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
