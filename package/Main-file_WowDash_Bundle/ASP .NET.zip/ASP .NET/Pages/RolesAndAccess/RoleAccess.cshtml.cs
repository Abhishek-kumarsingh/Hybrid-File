using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.RolesAndAccess
{
    public class RoleAccessModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
