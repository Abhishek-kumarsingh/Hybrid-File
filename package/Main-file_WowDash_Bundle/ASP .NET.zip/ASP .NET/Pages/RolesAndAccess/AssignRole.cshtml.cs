using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.RolesAndAccess
{
    public class AssignRoleModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
