using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Settings
{
    public class NotificationAlertModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
