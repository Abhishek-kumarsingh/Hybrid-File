using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Settings
{
    public class CurrenciesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
