using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Settings
{
    public class NotificationModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
