using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages
{
    public class FaqsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
