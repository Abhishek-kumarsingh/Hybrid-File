using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Components
{
    public class AlertsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
