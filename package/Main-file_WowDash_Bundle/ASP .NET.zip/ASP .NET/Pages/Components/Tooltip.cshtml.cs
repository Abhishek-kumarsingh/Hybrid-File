using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Components
{
    public class TooltipModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
