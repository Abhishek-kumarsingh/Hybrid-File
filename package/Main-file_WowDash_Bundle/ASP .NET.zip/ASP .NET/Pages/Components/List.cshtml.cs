using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Components
{
    public class ListModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
