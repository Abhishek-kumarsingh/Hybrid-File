using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Components
{
    public class StarRatingsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
