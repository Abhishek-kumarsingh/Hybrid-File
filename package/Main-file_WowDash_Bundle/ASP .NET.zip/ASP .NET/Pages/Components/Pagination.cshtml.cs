using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Components
{
    public class PaginationModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
