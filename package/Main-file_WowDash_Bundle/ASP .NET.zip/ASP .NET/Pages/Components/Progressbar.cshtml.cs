using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Components
{
    public class ProgressbarModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
