using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Components
{
    public class TagsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
