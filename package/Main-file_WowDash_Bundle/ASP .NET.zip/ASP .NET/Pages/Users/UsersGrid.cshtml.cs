using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Users
{
    public class UsersGridModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
