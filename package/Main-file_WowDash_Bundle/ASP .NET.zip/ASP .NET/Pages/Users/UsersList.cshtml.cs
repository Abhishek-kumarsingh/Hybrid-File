using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Users
{
    public class UsersListModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
