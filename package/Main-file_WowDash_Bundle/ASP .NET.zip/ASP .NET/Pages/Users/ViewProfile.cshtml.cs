using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Users
{
    public class ViewProfileModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
