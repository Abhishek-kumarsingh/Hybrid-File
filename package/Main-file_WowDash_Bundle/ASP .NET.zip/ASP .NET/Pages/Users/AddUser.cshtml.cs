using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Users
{
    public class AddUserModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
