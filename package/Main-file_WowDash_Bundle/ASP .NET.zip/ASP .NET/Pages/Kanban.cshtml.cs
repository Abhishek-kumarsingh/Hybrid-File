using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages
{
    public class KanbanModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
