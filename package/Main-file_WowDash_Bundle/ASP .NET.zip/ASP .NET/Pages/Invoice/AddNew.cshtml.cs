using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Invoice
{
    public class AddNewModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
