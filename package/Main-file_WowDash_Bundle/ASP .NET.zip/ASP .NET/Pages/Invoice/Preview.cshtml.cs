using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Invoice
{
    public class PreviewModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
