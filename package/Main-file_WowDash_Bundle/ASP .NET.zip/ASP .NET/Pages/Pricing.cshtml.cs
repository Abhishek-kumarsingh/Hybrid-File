using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages
{
    public class PricingModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
