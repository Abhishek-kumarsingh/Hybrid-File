using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages
{
    public class GalleryModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
