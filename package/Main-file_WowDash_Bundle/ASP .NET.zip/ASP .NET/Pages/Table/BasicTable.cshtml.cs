using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Table
{
    public class BasicTableModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
