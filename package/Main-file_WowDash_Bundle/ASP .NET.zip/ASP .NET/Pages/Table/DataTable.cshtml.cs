using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WowDash.Pages.Table
{
    public class DataTableModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
