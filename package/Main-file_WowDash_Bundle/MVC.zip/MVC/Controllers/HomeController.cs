using Microsoft.AspNetCore.Mvc;

namespace WowDash.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Home()
        {
            return View();
        }
        public IActionResult Chat()
        {
            return View();
        }
        public IActionResult ChatProfile()
        {
            return View();
        }
        public IActionResult Email()
        {
            return View();
        }
        public IActionResult Faqs()
        {
            return View();
        }
        public IActionResult Calendar()
        {
            return View();
        }
        public IActionResult Gallery()
        {
            return View();
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Kanban()
        {
            return View();
        }
        public IActionResult NotFound()
        {
            return View();
        }
        public IActionResult Pricing()
        {
            return View();
        }
        public IActionResult Stared()
        {
            return View();
        }
        public IActionResult TermsAndConditions()
        {
            return View();
        }
        public IActionResult ViewDetails()
        {
            return View();
        }
        public IActionResult Widgets()
        {
            return View();
        }
        public IActionResult Testimonials()
        {
            return View();
        }
        public IActionResult Comingsoon()
        {
            return View();
        }
        public IActionResult Maintenance()
        {
            return View();
        }
        public IActionResult BlankPage()
        {
            return View();
        }


    }
}
