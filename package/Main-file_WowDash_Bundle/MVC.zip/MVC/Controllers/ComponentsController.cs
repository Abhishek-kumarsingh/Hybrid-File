﻿using Microsoft.AspNetCore.Mvc;

namespace WowDash.Controllers
{
    public class ComponentsController : Controller
    {
        public IActionResult Alerts()
        {
            return View();
        }
        public IActionResult Avatars()
        {
            return View();
        }
        public IActionResult Badges()
        {
            return View();
        }
        public IActionResult Button()
        {
            return View();
        }
        public IActionResult Calendar()
        {
            return View();
        }
        public IActionResult Card()
        {
            return View();
        }
        public IActionResult Carousel()
        {
            return View();
        }
        public IActionResult Colors()
        {
            return View();
        }
        public IActionResult Dropdown()
        {
            return View();
        }
        public IActionResult List()
        {
            return View();
        }
        public IActionResult Pagination()
        {
            return View();
        }
        public IActionResult Progressbar()
        {
            return View();
        }
        public IActionResult Radio()
        {
            return View();
        }
        public IActionResult StarRatings()
        {
            return View();
        }
        public IActionResult Switch()
        {
            return View();
        }
        public IActionResult TabAndAccordion()
        {
            return View();
        }
        public IActionResult Tags()
        {
            return View();
        }
        public IActionResult Tooltip()
        {
            return View();
        }
        public IActionResult Typography()
        {
            return View();
        }
        public IActionResult Upload()
        {
            return View();
        }
        public IActionResult Videos()
        {
            return View();
        }
    }
}
