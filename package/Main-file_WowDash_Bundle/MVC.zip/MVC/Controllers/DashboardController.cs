﻿using Microsoft.AspNetCore.Mvc;

namespace WowDash.Controllers
{
    public class DashboardController : Controller
    {
        public IActionResult Index2()
        {
            return View();
        }
        public IActionResult Index3()
        {
            return View();
        }
        public IActionResult Index4()
        {
            return View();
        }
        public IActionResult Index5()
        {
            return View();
        }
        public IActionResult Index6()
        {
            return View();
        }
        public IActionResult Index7()
        {
            return View();
        }
        public IActionResult Index8()
        {
            return View();
        }
        public IActionResult Index9()
        {
            return View();
        }
        public IActionResult Index10()
        {
            return View();
        }
    }
}
