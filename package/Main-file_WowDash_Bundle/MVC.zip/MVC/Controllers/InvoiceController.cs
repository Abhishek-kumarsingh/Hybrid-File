﻿using Microsoft.AspNetCore.Mvc;

namespace WowDash.Controllers
{
    public class InvoiceController : Controller
    {
        public IActionResult AddNew()
        {
            return View();
        }
        public IActionResult Edit()
        {
            return View();
        }
        public IActionResult List()
        {
            return View();
        }
        public IActionResult Preview()
        {
            return View();
        }
    }
}
