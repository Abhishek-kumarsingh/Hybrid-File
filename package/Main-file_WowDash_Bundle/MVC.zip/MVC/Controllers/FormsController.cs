﻿using Microsoft.AspNetCore.Mvc;

namespace WowDash.Controllers
{
    public class FormsController : Controller
    {
        public IActionResult FormValidation()
        {
            return View();
        }
        public IActionResult FormWizard()
        {
            return View();
        }
        public IActionResult InputForms()
        {
            return View();
        }
        public IActionResult InputLayout()
        {
            return View();
        }
    }
}
