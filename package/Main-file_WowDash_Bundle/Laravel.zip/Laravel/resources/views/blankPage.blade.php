@extends('layout.layout')

@php
    $title='Blank Page';
    $subTitle = 'Blank Page';
@endphp

@section('content')


@endsection