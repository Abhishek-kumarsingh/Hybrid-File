<footer class="d-footer">
    <div class="row align-items-center justify-content-between">
        <div class="col-auto">
            <p class="mb-0">© 2024 WowDash. All Rights Reserved.</p>
        </div>
        <div class="col-auto">
            <p class="mb-0">Made by <span class="text-primary-600">wowtheme7</span></p>
        </div>
    </div>
</footer><?php /**PATH D:\Laravel\wowdash\resources\views/components/footer.blade.php ENDPATH**/ ?>