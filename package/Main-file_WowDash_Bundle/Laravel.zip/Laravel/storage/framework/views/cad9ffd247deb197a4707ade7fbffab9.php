

<?php
    $title='Blank Page';
    $subTitle = 'Blank Page';
?>

<?php $__env->startSection('content'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\wowdash - 2\resources\views/blankPage.blade.php ENDPATH**/ ?>