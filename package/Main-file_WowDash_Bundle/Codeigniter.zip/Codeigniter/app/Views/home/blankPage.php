<?= $this->extend('layout/layout1'); ?>


<?= $this->section('content'); ?> 


<?= $this->endSection(); ?>